'use client'

import { ChatSidebar } from '@/components/chat-sidebar'
import { ChatHeader } from '@/components/chat-header'
import { ChatMessages, ChatMessage } from '@/components/chat-messages'
import { ChatInput } from '@/components/chat-input'
import { Background3D } from '@/components/background-3d'
import { useState } from 'react'

const SAMPLE_MESSAGES: ChatMessage[] = [
  {
    id: '1',
    role: 'user',
    content: 'What are some best practices for React component design?',
    timestamp: new Date(Date.now() - 5 * 60000),
  },
  {
    id: '2',
    role: 'assistant',
    content:
      'Great question! Here are some key best practices for React component design:\n\n1. Single Responsibility - Each component should have one clear purpose\n2. Composition - Build complex UIs from simpler, reusable components\n3. Props - Use props to customize component behavior\n4. Memoization - Optimize performance with React.memo for expensive components\n5. Custom Hooks - Extract logic into reusable hooks\n\nWould you like me to elaborate on any of these?',
    timestamp: new Date(Date.now() - 4 * 60000),
  },
  {
    id: '3',
    role: 'user',
    content: 'Can you explain composition with an example?',
    timestamp: new Date(Date.now() - 2 * 60000),
  },
  {
    id: '4',
    role: 'assistant',
    content:
      'Of course! Here\'s a practical example of composition:\n\nInstead of creating a monolithic component:\n```jsx\nfunction UserProfile({ user }) {\n  return (\n    <div>\n      <img src={user.avatar || "/placeholder.svg"} />\n      <h1>{user.name}</h1>\n      <p>{user.bio}</p>\n    </div>\n  )\n}\n```\n\nBreak it into smaller, reusable components:\n```jsx\nfunction Avatar({ src }) { return <img src={src || "/placeholder.svg"} /> }\nfunction UserName({ name }) { return <h1>{name}</h1> }\nfunction UserBio({ bio }) { return <p>{bio}</p> }\n\nfunction UserProfile({ user }) {\n  return (\n    <div>\n      <Avatar src={user.avatar} />\n      <UserName name={user.name} />\n      <UserBio bio={user.bio} />\n    </div>\n  )\n}\n```\n\nThis approach makes components more testable and reusable!',
    timestamp: new Date(Date.now() - 1 * 60000),
  },
]

export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>(SAMPLE_MESSAGES)
  const [isLoading, setIsLoading] = useState(false)
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null)

  const handleSendMessage = (content: string) => {
    // Add user message
    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      const assistantMessage: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content:
          "I'm a demo assistant. In a real application, this would be connected to an AI API to generate responses based on your message.",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, assistantMessage])
      setIsLoading(false)
    }, 1500)
  }

  return (
    <div className="h-screen w-full flex bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* 3D Background Scene */}
      <Background3D enabled={true} />

      {/* Background blur effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl opacity-20" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl opacity-10" />
      </div>

      {/* Sidebar */}
      <ChatSidebar onSelectChat={setSelectedChatId} />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col ml-64 relative z-10">
        {/* Header */}
        <ChatHeader title={selectedChatId ? 'Chat' : 'New Chat'} />

        {/* Messages */}
        <ChatMessages messages={messages} isLoading={isLoading} />

        {/* Input */}
        <ChatInput onSendMessage={handleSendMessage} disabled={isLoading} isEmpty={messages.length === 0} />
      </div>
    </div>
  )
}
