'use client'

import { ChevronLeft } from 'lucide-react'
import { useState } from 'react'

interface SettingsPanelProps {
  isOpen: boolean
  onClose: () => void
}

export function SettingsPanel({ isOpen, onClose }: SettingsPanelProps) {
  const [theme, setTheme] = useState('dark')
  const [motionPreference, setMotionPreference] = useState('normal')
  const [enable3DBackground, setEnable3DBackground] = useState(true)
  const [responseVoice, setResponseVoice] = useState('neutral')
  const [responseStyle, setResponseStyle] = useState('neutral')
  const [saveHistory, setSaveHistory] = useState(true)
  const [autoDeleteHistory, setAutoDeleteHistory] = useState('never')
  const [showClearConfirmation, setShowClearConfirmation] = useState(false)

  const themeOptions = [
    { value: 'dark', label: 'Dark' },
    { value: 'system', label: 'System' },
    { value: 'light', label: 'Light' },
  ]

  const voiceOptions = [
    { value: 'neutral', label: 'Neutral' },
    { value: 'male', label: 'Male' },
    { value: 'female', label: 'Female' },
  ]

  const styleOptions = [
    { value: 'neutral', label: 'Neutral' },
    { value: 'formal', label: 'Formal' },
    { value: 'casual', label: 'Casual' },
    { value: 'concise', label: 'Concise' },
    { value: 'detailed', label: 'Detailed' },
    { value: 'teaching', label: 'Teaching Mode' },
  ]

  const autoDeleteOptions = [
    { value: 'never', label: 'Never' },
    { value: '7days', label: 'After 7 days' },
    { value: '30days', label: 'After 30 days' },
  ]

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 animate-fade-in-backdrop"
        onClick={onClose}
        aria-label="Close settings"
      />

      {/* Settings Slide-in Panel */}
      <div className="fixed top-0 right-0 bottom-0 w-full max-w-md glass-dark border-l border-white/10 flex flex-col z-50 animate-slide-in-right shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <h2 className="text-lg font-semibold text-white">Settings</h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors duration-150"
          >
            <ChevronLeft size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto space-y-6 p-4">
          {/* Appearance Section */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">Appearance</h3>
            <div className="space-y-3">
              {/* Theme Selection */}
              <div>
                <label className="text-xs text-white/60 uppercase tracking-wider block mb-2">
                  Theme
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {themeOptions.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => setTheme(opt.value)}
                      className={`px-3 py-2 text-xs font-medium rounded-lg transition-all duration-150 ${
                        theme === opt.value
                          ? 'bg-white/20 text-white'
                          : 'glass-sm text-white/70 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Motion Preference */}
              <div>
                <label className="text-xs text-white/60 uppercase tracking-wider block mb-2">
                  Motion
                </label>
                <div className="flex gap-2">
                  {['normal', 'reduced'].map((opt) => (
                    <button
                      key={opt}
                      onClick={() => setMotionPreference(opt)}
                      className={`flex-1 px-3 py-2 text-xs font-medium rounded-lg transition-all duration-150 ${
                        motionPreference === opt
                          ? 'bg-white/20 text-white'
                          : 'glass-sm text-white/70 hover:text-white'
                      }`}
                    >
                      {opt.charAt(0).toUpperCase() + opt.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              {/* 3D Background Toggle */}
              <div className="flex items-center justify-between glass-sm p-3 rounded-lg">
                <label className="text-sm text-white/80">3D Background</label>
                <button
                  onClick={() => setEnable3DBackground(!enable3DBackground)}
                  className={`relative w-12 h-6 rounded-full transition-all duration-200 ${
                    enable3DBackground ? 'bg-white/30' : 'bg-white/10'
                  }`}
                >
                  <div
                    className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform duration-200 ${
                      enable3DBackground ? 'right-1' : 'left-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Conversation Section */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">Conversation</h3>
            <div className="space-y-3">
              {/* Response Voice */}
              <div>
                <label className="text-xs text-white/60 uppercase tracking-wider block mb-2">
                  Response Voice
                </label>
                <div className="space-y-2">
                  {voiceOptions.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => setResponseVoice(opt.value)}
                      className={`w-full text-left px-3 py-2 text-sm rounded-lg transition-all duration-150 ${
                        responseVoice === opt.value
                          ? 'bg-white/20 text-white'
                          : 'glass-sm text-white/70 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Response Style */}
              <div>
                <label className="text-xs text-white/60 uppercase tracking-wider block mb-2">
                  Response Style
                </label>
                <div className="space-y-2">
                  {styleOptions.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => setResponseStyle(opt.value)}
                      className={`w-full text-left px-3 py-2 text-sm rounded-lg transition-all duration-150 ${
                        responseStyle === opt.value
                          ? 'bg-white/20 text-white'
                          : 'glass-sm text-white/70 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* History Section */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3">History</h3>
            <div className="space-y-3">
              {/* Save History Toggle */}
              <div className="flex items-center justify-between glass-sm p-3 rounded-lg">
                <label className="text-sm text-white/80">Save Chat History</label>
                <button
                  onClick={() => setSaveHistory(!saveHistory)}
                  className={`relative w-12 h-6 rounded-full transition-all duration-200 ${
                    saveHistory ? 'bg-white/30' : 'bg-white/10'
                  }`}
                >
                  <div
                    className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform duration-200 ${
                      saveHistory ? 'right-1' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              {/* Auto-Delete Options */}
              {saveHistory && (
                <div>
                  <label className="text-xs text-white/60 uppercase tracking-wider block mb-2">
                    Auto-Delete
                  </label>
                  <div className="space-y-2">
                    {autoDeleteOptions.map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() => setAutoDeleteHistory(opt.value)}
                        className={`w-full text-left px-3 py-2 text-sm rounded-lg transition-all duration-150 ${
                          autoDeleteHistory === opt.value
                            ? 'bg-white/20 text-white'
                            : 'glass-sm text-white/70 hover:text-white'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Clear History Button */}
              <button
                onClick={() => setShowClearConfirmation(true)}
                className="w-full px-3 py-2.5 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 glass-sm rounded-lg transition-colors duration-150"
              >
                Clear All History
              </button>
            </div>
          </div>
        </div>

        {/* Clear History Confirmation */}
        {showClearConfirmation && (
          <div className="border-t border-white/10 p-4 space-y-3 glass-dark">
            <p className="text-sm text-white/80">Clear all chat history?</p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowClearConfirmation(false)}
                className="flex-1 px-3 py-2 text-sm text-white/70 hover:text-white glass-sm rounded-lg transition-colors duration-150"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowClearConfirmation(false)}
                className="flex-1 px-3 py-2 text-sm text-white font-medium bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors duration-150"
              >
                Clear
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  )
}
