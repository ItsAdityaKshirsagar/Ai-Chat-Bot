'use client'

import { Plus, Search, Settings, MoreHorizontal, Pencil, Archive, Trash2, X } from 'lucide-react'
import { useState } from 'react'
import { SettingsPanel } from './settings-panel'

const CHAT_MODES = [
  { id: 'friendly', name: 'Friendly Chat', description: 'Casual and conversational', icon: '💬' },
  { id: 'tutor', name: 'Teaching / Tutor', description: 'Educational explanations', icon: '📚' },
  { id: 'interview', name: 'Interview Preparation', description: 'Mock interviews & tips', icon: '🎯' },
  { id: 'code', name: 'Code Explanation', description: 'Technical code walkthroughs', icon: '💻' },
  { id: 'career', name: 'Career Guidance', description: 'Professional advice', icon: '🚀' },
]

const CHAT_HISTORY = {
  today: [
    { id: '1', title: 'React optimization techniques', lastUpdated: new Date() },
    { id: '2', title: 'TypeScript advanced patterns', lastUpdated: new Date(Date.now() - 3600000) },
  ],
  yesterday: [
    { id: '3', title: 'Database design principles', lastUpdated: new Date(Date.now() - 86400000) },
    { id: '4', title: 'API security best practices', lastUpdated: new Date(Date.now() - 90000000) },
  ],
  last7days: [
    { id: '5', title: 'Next.js 14 features', lastUpdated: new Date(Date.now() - 259200000) },
    { id: '6', title: 'CSS Grid layouts', lastUpdated: new Date(Date.now() - 432000000) },
  ],
  older: [
    { id: '7', title: 'JavaScript async/await', lastUpdated: new Date(Date.now() - 864000000) },
    { id: '8', title: 'Git workflow strategies', lastUpdated: new Date(Date.now() - 1728000000) },
  ],
}

interface ChatSidebarProps {
  onSelectChat?: (id: string) => void
}

export function ChatSidebar({ onSelectChat }: ChatSidebarProps) {
  const [modeSearch, setModeSearch] = useState('')
  const [showModeDropdown, setShowModeDropdown] = useState(false)
  const [selectedMode, setSelectedMode] = useState<string | null>(null)
  const [historySearch, setHistorySearch] = useState('')
  const [hoveredChatId, setHoveredChatId] = useState<string | null>(null)
  const [editingChatId, setEditingChatId] = useState<string | null>(null)
  const [editingTitle, setEditingTitle] = useState('')
  const [archivedChats, setArchivedChats] = useState<Set<string>>(new Set())
  const [deletingChatId, setDeletingChatId] = useState<string | null>(null)
  const [undoDeleteChatId, setUndoDeleteChatId] = useState<string | null>(null)
  const [deletedChats, setDeletedChats] = useState<Set<string>>(new Set())
  const [search, setSearch] = useState('') // Declare search variable
  const [showSettings, setShowSettings] = useState(false)

  const filteredModes = CHAT_MODES.filter((mode) =>
    mode.name.toLowerCase().includes(modeSearch.toLowerCase()) ||
    mode.description.toLowerCase().includes(modeSearch.toLowerCase())
  )

  const handleSelectMode = (modeId: string) => {
    setSelectedMode(modeId)
    setShowModeDropdown(false)
    setModeSearch('')
  }

  const handleStartRename = (chatId: string, currentTitle: string) => {
    setEditingChatId(chatId)
    setEditingTitle(currentTitle)
  }

  const handleSaveRename = (chatId: string) => {
    setEditingChatId(null)
    setEditingTitle('')
  }

  const handleArchive = (chatId: string) => {
    setArchivedChats((prev) => {
      const next = new Set(prev)
      if (next.has(chatId)) {
        next.delete(chatId)
      } else {
        next.add(chatId)
      }
      return next
    })
  }

  const handleDeleteClick = (chatId: string) => {
    setDeletingChatId(chatId)
    setTimeout(() => {
      setDeletedChats((prev) => new Set(prev).add(chatId))
      setDeletingChatId(null)
      setUndoDeleteChatId(chatId)
      setTimeout(() => {
        setUndoDeleteChatId(null)
      }, 4000)
    }, 800)
  }

  const handleUndoDelete = (chatId: string) => {
    setDeletedChats((prev) => {
      const next = new Set(prev)
      next.delete(chatId)
      return next
    })
    setUndoDeleteChatId(null)
  }

  const renderChatHistory = () => {
    const allChats = Object.values(CHAT_HISTORY).flat()
    const filteredChats = allChats.filter((chat) =>
      chat.title.toLowerCase().includes(historySearch.toLowerCase())
    )

    if (historySearch && filteredChats.length === 0) {
      return (
        <div className="text-center py-8 px-4">
          <p className="text-sm text-white/40">No chats found matching your search</p>
        </div>
      )
    }

    if (Object.values(CHAT_HISTORY).flat().length === 0) {
      return (
        <div className="text-center py-8 px-4">
          <p className="text-sm text-white/40">No chat history yet</p>
        </div>
      )
    }

    const groups = [
      { label: 'Today', key: 'today' },
      { label: 'Yesterday', key: 'yesterday' },
      { label: 'Last 7 Days', key: 'last7days' },
      { label: 'Older', key: 'older' },
    ]

    return (
      <>
        {groups.map(({ label, key }) => {
          const groupChats = (CHAT_HISTORY[key as keyof typeof CHAT_HISTORY] || []).filter(
            (chat) =>
              chat.title.toLowerCase().includes(historySearch.toLowerCase()) &&
              !deletedChats.has(chat.id)
          )

          if (groupChats.length === 0) return null

          return (
            <div key={key}>
              <h3 className="text-xs uppercase tracking-wider text-white/40 mb-2">{label}</h3>
              <div className="space-y-1 mb-4">
                {groupChats.map((chat) => (
                  <div
                    key={chat.id}
                    className={`group relative transition-all duration-200 ${
                      archivedChats.has(chat.id) ? 'opacity-40' : ''
                    }`}
                    onMouseEnter={() => setHoveredChatId(chat.id)}
                    onMouseLeave={() => setHoveredChatId(null)}
                  >
                    <button
                      onClick={() => onSelectChat?.(chat.id)}
                      className="w-full text-left px-3 py-2 text-sm text-white/70 hover:text-white rounded-lg hover:bg-white/10 transition-colors duration-150 truncate"
                    >
                      {editingChatId === chat.id ? (
                        <input
                          type="text"
                          value={editingTitle}
                          onChange={(e) => setEditingTitle(e.target.value)}
                          onBlur={() => handleSaveRename(chat.id)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSaveRename(chat.id)
                            if (e.key === 'Escape') setEditingChatId(null)
                          }}
                          autoFocus
                          className="w-full bg-white/20 text-white px-2 py-1 rounded text-sm focus:outline-none focus:ring-1 focus:ring-white/40"
                        />
                      ) : (
                        <span className={archivedChats.has(chat.id) ? 'line-through' : ''}>
                          {chat.title}
                        </span>
                      )}
                    </button>

                    {hoveredChatId === chat.id && editingChatId !== chat.id && (
                      <div className="absolute right-1 top-1/2 -translate-y-1/2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
                        <button
                          onClick={() => handleStartRename(chat.id, chat.title)}
                          className="p-1.5 rounded hover:bg-white/10 text-white/50 hover:text-white transition-colors duration-150"
                          title="Rename"
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          onClick={() => handleArchive(chat.id)}
                          className="p-1.5 rounded hover:bg-white/10 text-white/50 hover:text-white transition-colors duration-150"
                          title={archivedChats.has(chat.id) ? 'Unarchive' : 'Archive'}
                        >
                          <Archive size={14} />
                        </button>
                        <button
                          onClick={() => handleDeleteClick(chat.id)}
                          className="p-1.5 rounded hover:bg-red-500/20 text-white/50 hover:text-red-400 transition-colors duration-150"
                          title="Delete"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </>
    )
  }

  return (
    <div className="glass-dark fixed left-0 top-0 bottom-0 w-64 p-4 flex flex-col border-r border-white/10">
      {/* Logo / Title */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white tracking-tight">ChatGPT</h1>
      </div>

      {/* New Chat Button */}
      <button className="glass-sm w-full py-2.5 px-3 mb-6 flex items-center justify-center gap-2 text-white/90 hover:text-white hover:bg-white/15 transition-all duration-200">
        <Plus size={18} />
        <span className="text-sm font-medium">New Chat</span>
      </button>

      {/* Chat Mode Selector */}
      <div className="mb-6 relative">
        <button
          onClick={() => setShowModeDropdown(!showModeDropdown)}
          className="glass-sm w-full py-2.5 px-3 flex items-center justify-between text-sm text-white/90 hover:text-white hover:bg-white/15 transition-all duration-200"
        >
          <span>
            {selectedMode
              ? CHAT_MODES.find((m) => m.id === selectedMode)?.name || 'Select Mode'
              : 'Select Mode'}
          </span>
          <span className="text-white/40">▼</span>
        </button>

        {showModeDropdown && (
          <div className="absolute top-full left-0 right-0 mt-2 glass-dark rounded-lg overflow-hidden z-50 w-full">
            {/* Mode Search */}
            <div className="p-2 border-b border-white/10">
              <div className="relative">
                <Search size={14} className="absolute left-2.5 top-2 text-white/40" />
                <input
                  type="text"
                  placeholder="Search modes..."
                  value={modeSearch}
                  onChange={(e) => setModeSearch(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-white/10 text-sm text-white placeholder-white/40 rounded focus:outline-none focus:ring-1 focus:ring-white/30"
                />
              </div>
            </div>

            {/* Mode List */}
            <div className="max-h-64 overflow-y-auto">
              {filteredModes.length === 0 ? (
                <div className="p-3 text-center">
                  <p className="text-xs text-white/40">No modes found</p>
                </div>
              ) : (
                filteredModes.map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => handleSelectMode(mode.id)}
                    className={`w-full text-left px-3 py-2.5 text-sm transition-colors duration-150 border-b border-white/5 last:border-b-0 ${
                      selectedMode === mode.id
                        ? 'bg-white/15 text-white'
                        : 'text-white/70 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <span className="text-base mt-0.5">{mode.icon}</span>
                      <div className="flex-1">
                        <div className="font-medium">{mode.name}</div>
                        <div className="text-xs text-white/50">{mode.description}</div>
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* History Search */}
      <div className="relative mb-6">
        <Search size={16} className="absolute left-3 top-3 text-white/40" />
        <input
          type="text"
          placeholder="Search chats..."
          value={historySearch}
          onChange={(e) => setHistorySearch(e.target.value)}
          className="glass-sm w-full pl-9 pr-3 py-2 text-sm text-white/90 placeholder-white/40 focus:outline-none focus:ring-1 focus:ring-white/30"
        />
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-2">{renderChatHistory()}</div>

      {/* Delete Confirmation Toast */}
      {undoDeleteChatId && (
        <div className="mb-4 glass-sm p-3 rounded-lg flex items-center justify-between animate-fade-in">
          <span className="text-xs text-white/70">Chat deleted</span>
          <button
            onClick={() => handleUndoDelete(undoDeleteChatId)}
            className="text-xs text-white/60 hover:text-white underline transition-colors duration-150"
          >
            Undo
          </button>
        </div>
      )}

      {/* Settings */}
      <div className="border-t border-white/10 pt-4">
        <button 
          onClick={() => setShowSettings(true)}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-colors duration-150"
        >
          <Settings size={18} />
          <span className="text-sm font-medium">Settings</span>
        </button>
      </div>

      {/* Settings Panel */}
      <SettingsPanel isOpen={showSettings} onClose={() => setShowSettings(false)} />
    </div>
  )
}
