'use client'

import { useEffect, useRef } from 'react'

export function Background3D({ enabled = true }: { enabled?: boolean }) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!enabled || !containerRef.current) return

    // Dynamic import to handle server-side rendering
    import('@react-three/fiber').then(({ Canvas }) => {
      import('@react-three/drei').then(({ OrbitControls }) => {
        import('three').then(({ Scene, PerspectiveCamera, WebGLRenderer, AmbientLight, DirectionalLight, Mesh, IcosahedronGeometry, MeshStandardMaterial }) => {
          // Simple placeholder scene setup
          // In production, this would be replaced with:
          // - A detailed futuristic colony scene (buildings, structures)
          // - Animated roaming robots (using loaded models or procedural geometry)
          // - Complex lighting to create atmosphere
          // - Particle effects for ambient elements

          let camera: PerspectiveCamera
          let renderer: WebGLRenderer

          const handleResize = () => {
            if (containerRef.current) {
              const width = containerRef.current.clientWidth
              const height = containerRef.current.clientHeight
              camera.aspect = width / height
              camera.updateProjectionMatrix()
              renderer.setSize(width, height)
            }
          }

          try {
            const scene = new Scene()
            camera = new PerspectiveCamera(
              75,
              containerRef.current?.clientWidth || 1 / (containerRef.current?.clientHeight || 1),
              0.1,
              1000
            )
            renderer = new WebGLRenderer({ antialias: true, alpha: true })

            if (containerRef.current) {
              renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
              renderer.setClearColor(0x0a0e27, 0)
              containerRef.current.appendChild(renderer.domElement)

              // Soft ambient lighting
              const ambientLight = new AmbientLight(0xffffff, 0.3)
              scene.add(ambientLight)

              // Directional light for depth
              const directionalLight = new DirectionalLight(0xffffff, 0.4)
              directionalLight.position.set(5, 5, 5)
              scene.add(directionalLight)

              // Simple floating geometry as placeholder
              // FUTURE: Replace with actual colony structures and robot models
              const geometry = new IcosahedronGeometry(1, 4)
              const material = new MeshStandardMaterial({
                color: 0x6366f1,
                roughness: 0.4,
                metalness: 0.6,
              })
              const mesh = new Mesh(geometry, material)
              mesh.position.z = -5
              scene.add(mesh)

              // Very slow camera movement for passive experience
              let animationFrameId: number
              let time = 0

              const animate = () => {
                animationFrameId = requestAnimationFrame(animate)
                time += 0.0003

                // Gentle orbital movement
                camera.position.x = Math.cos(time) * 8
                camera.position.y = Math.sin(time * 0.5) * 2 + 3
                camera.position.z = Math.sin(time) * 8 + 8
                camera.lookAt(0, 0, 0)

                // Subtle mesh rotation
                mesh.rotation.x += 0.0001
                mesh.rotation.y += 0.0002

                renderer.render(scene, camera)
              }

              animate()

              window.addEventListener('resize', handleResize)

              return () => {
                window.removeEventListener('resize', handleResize)
                cancelAnimationFrame(animationFrameId)
                containerRef.current?.removeChild(renderer.domElement)
                renderer.dispose()
                geometry.dispose()
                material.dispose()
              }
            }
          } catch (error) {
            console.error('[v0] 3D scene initialization error:', error)
          }
        })
      })
    })
  }, [enabled])

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 pointer-events-none"
      style={{
        opacity: enabled ? 1 : 0,
        transition: 'opacity 0.3s ease-out',
      }}
    />
  )
}
