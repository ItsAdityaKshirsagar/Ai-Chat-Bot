'use client'

import { MessageCircle } from 'lucide-react'

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp?: Date
}

interface ChatMessagesProps {
  messages: ChatMessage[]
  isLoading?: boolean
}

export function ChatMessages({ messages, isLoading }: ChatMessagesProps) {
  if (messages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center px-4 animate-fade-in">
        <div className="glass-dark p-8 rounded-2xl max-w-md">
          <MessageCircle size={48} className="mx-auto mb-4 text-white/40" />
          <h2 className="text-2xl font-semibold text-white mb-2">Start a conversation</h2>
          <p className="text-white/60 text-sm leading-relaxed">
            Ask me anything or discuss topics you're interested in
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto space-y-6 py-8 px-8">
      {messages.map((message, idx) => (
        <div
          key={message.id}
          className={`flex gap-4 ${message.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}
          style={{ animationDelay: `${idx * 0.1}s` }}
        >
          {message.role === 'assistant' && (
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0 flex items-center justify-center text-white text-xs font-bold mt-1">
              AI
            </div>
          )}

          <div
            className={`max-w-md lg:max-w-2xl ${
              message.role === 'user'
                ? 'glass-sm bg-white/5 text-white'
                : 'glass-dark bg-white/5 text-white/90'
            } p-4 rounded-xl backdrop-blur-md border border-white/20 hover:bg-white/10 transition-colors duration-200`}
          >
            <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{message.content}</p>
            {message.timestamp && (
              <p className="text-xs text-white/40 mt-3">
                {message.timestamp.toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
            )}
          </div>

          {message.role === 'user' && (
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex-shrink-0 flex items-center justify-center text-white text-xs font-bold mt-1">
              U
            </div>
          )}
        </div>
      ))}

      {isLoading && (
        <div className="flex gap-4 justify-start animate-fade-in">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0 flex items-center justify-center text-white text-xs font-bold mt-1">
            AI
          </div>
          <div className="glass-dark bg-white/5 p-4 rounded-xl backdrop-blur-md border border-white/20">
            <div className="flex gap-2">
              <div className="w-2 h-2 rounded-full bg-white/40 animate-bounce" />
              <div className="w-2 h-2 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0.2s' }} />
              <div className="w-2 h-2 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0.4s' }} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
