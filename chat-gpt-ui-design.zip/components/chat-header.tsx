'use client'

import { MoreVertical } from 'lucide-react'

interface ChatHeaderProps {
  title?: string
}

export function ChatHeader({ title = 'New Chat' }: ChatHeaderProps) {
  return (
    <div className="glass-dark border-b border-white/10 px-6 py-4 flex items-center justify-between">
      <h2 className="text-white font-semibold text-lg">{title}</h2>
      <button className="p-2 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors duration-150">
        <MoreVertical size={18} />
      </button>
    </div>
  )
}
