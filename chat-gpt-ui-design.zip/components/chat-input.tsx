'use client'

import React from "react"
import { Send, Paperclip, Mic, Plus, Settings2, MessageSquare } from 'lucide-react'
import { useState, useRef } from 'react'

interface ChatInputProps {
  onSendMessage?: (message: string) => void
  disabled?: boolean
  isEmpty?: boolean
}

export function ChatInput({ onSendMessage, disabled, isEmpty }: ChatInputProps) {
  const [input, setInput] = useState('')
  const [isVoiceMode, setIsVoiceMode] = useState(false)
  const [showModePopover, setShowModePopover] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim() && !disabled) {
      onSendMessage?.(input.trim())
      setInput('')
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto'
      }
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e as unknown as React.FormEvent)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value)
    // Auto-expand textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px'
    }
  }

  const chatStarters = [
    { icon: '💡', text: 'Explain a concept' },
    { icon: '✍️', text: 'Help me write' },
    { icon: '🐛', text: 'Debug code' },
    { icon: '🎯', text: 'Brainstorm ideas' },
  ]

  return (
    <div className="glass-dark p-4 mx-4 mb-4 border-t border-white/10 space-y-4">
      {/* Chat Starters - Only show when chat is empty */}
      {isEmpty && (
        <div className="grid grid-cols-2 gap-2 mb-4">
          {chatStarters.map((starter, idx) => (
            <button
              key={idx}
              onClick={() => {
                setInput(starter.text)
                textareaRef.current?.focus()
              }}
              className="glass-sm p-3 text-left hover:bg-white/20 transition-colors duration-150 group"
            >
              <div className="text-lg mb-1">{starter.icon}</div>
              <div className="text-white/80 text-xs group-hover:text-white">{starter.text}</div>
            </button>
          ))}
        </div>
      )}

      {/* Mode Popover */}
      {showModePopover && (
        <div className="glass-sm p-3 space-y-2">
          <div className="text-white/60 text-xs font-medium">Chat Mode</div>
          <div className="glass-dark p-2.5 rounded-lg text-white text-sm flex items-center gap-2">
            <MessageSquare size={16} />
            <span>General Chat</span>
            <span className="ml-auto text-white/40 text-xs">Active</span>
          </div>
          
          <div className="text-white/60 text-xs font-medium mt-3">Message Focus</div>
          <button className="w-full glass-dark p-2.5 rounded-lg text-white/70 hover:text-white text-sm transition-colors duration-150 text-left">
            Focus on latest message
          </button>
        </div>
      )}

      {/* Input Area */}
      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="flex gap-2.5 items-end">
          {/* Left Actions */}
          <div className="flex gap-2">
            {/* Voice Mode */}
            <button
              type="button"
              onClick={() => setIsVoiceMode(!isVoiceMode)}
              className={`p-2.5 rounded-lg transition-all duration-150 flex-shrink-0 ${
                isVoiceMode
                  ? 'bg-purple-500/30 text-purple-300'
                  : 'text-white/60 hover:text-white hover:bg-white/10'
              }`}
              title={isVoiceMode ? 'Voice Mode: ON' : 'Voice Mode: OFF'}
            >
              <Mic size={18} />
            </button>

            {/* Mode / Tools */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowModePopover(!showModePopover)}
                className="p-2.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors duration-150 flex-shrink-0"
                title="Mode and Tools"
              >
                <Settings2 size={18} />
              </button>
            </div>

            {/* Disabled + Button */}
            <button
              type="button"
              disabled
              className="p-2.5 rounded-lg text-white/30 cursor-not-allowed flex-shrink-0"
              title="Add tools (coming soon)"
            >
              <Plus size={18} />
            </button>
          </div>

          {/* Main Input */}
          <div className="flex-1 glass-sm">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Send a message... (Shift+Enter for new line)"
              disabled={disabled}
              rows={1}
              className="w-full px-4 py-2.5 bg-transparent text-white/90 placeholder-white/40 focus:outline-none text-sm resize-none overflow-y-auto max-h-30"
            />
          </div>

          {/* Send Button */}
          <button
            type="submit"
            disabled={disabled || !input.trim()}
            className="p-2.5 rounded-lg bg-white/10 hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed text-white/70 hover:text-white transition-all duration-150 flex-shrink-0"
            title="Send message"
          >
            <Send size={18} />
          </button>
        </div>
      </form>
    </div>
  )
}
